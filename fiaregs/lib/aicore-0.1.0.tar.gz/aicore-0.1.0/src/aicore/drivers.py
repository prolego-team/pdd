"""Main functions for creating search and LLM interactions."""

import logging
from typing import Callable
import os

os.environ['TOKENIZERS_PARALLELISM'] = 'false'

import chromadb

from aicore.text.text import SearchResult
from aicore.llm import openaiapi as oai
from aicore.llm.messages import UserMessage, AssistantMessage, SystemMessage


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def make_search_function(
        collection: chromadb.Collection,
        top_k: int
    ) -> Callable[[str], list[SearchResult]]:
    """Make a search function. The search function takes a string query and returns a
    list of SearchResults."""

    def search(query: str) -> list[SearchResult]:
        # move the query function to the chroma module
        # then this func is responsible for formatting the results
        results = collection.query(
            query_texts=[query],
            include=['metadatas', 'documents', 'distances'],
            n_results=top_k
        )

        results_structured = []
        for i in range(len(results['ids'][0])):
            results_structured.append(
                SearchResult(
                    similarity_score=1-results['distances'][0][i],
                    file=results['metadatas'][0][i]['file'],
                    tree_index=(results['metadatas'][0][i]['page'], results['metadatas'][0][i]['paragraph']),
                    paragraph_index=results['metadatas'][0][i]['paragraph'],
                    chunk_id=results['ids'][0][i],
                    text=results['documents'][0][i]
                )
            )
        return results_structured

    return search


def make_llm_function(
        llm_client: oai.openai.Client,
        llm_model_name: str,
        system_message: str,
        tracker: oai.UsageTracker | None = None
    ) -> Callable[[str, list[tuple[str,str]]], str]:
    """Make a chat-based LLM function. The function takes a user query and a history of
    user and assistant messages and returns a string response."""

    llm_chat = oai.start_chat(
        llm_model_name,
        llm_client,
        tracker
    )

    def llm(user_query: str, history: list[tuple[str,str]]) -> str:
        messages = [SystemMessage(system_message)]
        for user_msg, assistant_msg in history:
            messages += [UserMessage(user_msg), AssistantMessage(assistant_msg)]

        messages.append(UserMessage(user_query))

        response_msg = llm_chat(messages)

        return response_msg.content

    return llm
