import logging

import chromadb
from chromadb.utils import embedding_functions

from aicore.text.text import Document

logger = logging.getLogger(__name__)


metadata_to_id = lambda metadata: f"{metadata['file']}_{metadata['page']}_{metadata['paragraph']}"


def get_or_create_collection(client: chromadb.Client, emb_model_name: str, collection_name: str) -> chromadb.Collection:
    """Get or create a collection."""

    emb_func = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=emb_model_name)
    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=emb_func,
        metadata={"hnsw:space": "cosine"}
    )

    return collection


def doc_is_in_collection(collection: chromadb.Collection, doc_name: str) -> bool:
    return len(collection.get(where={'file': doc_name}, include=['metadatas'])['ids'])>0


def add_doc(collection: chromadb.Collection, doc: Document, doc_name: str) -> None:

    if doc_is_in_collection(collection, doc_name):
        logger.info(f'Document {doc_name} already in collection')
        return

    texts = [text_block for page in doc for text_block in page.text_blocks]
    metadata = [
        {
            'page': page.page_num,
            'paragraph': block_num,
            'file': doc_name,
        }
        for page in doc for block_num,_ in enumerate(page.text_blocks)
    ]
    collection.add(
        documents=texts,
        metadatas=metadata,
        ids=list(map(metadata_to_id, metadata))
    )
