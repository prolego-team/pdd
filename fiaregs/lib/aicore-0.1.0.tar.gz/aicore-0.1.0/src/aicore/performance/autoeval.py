from typing import Callable

from aicore.llm.messages import SystemMessage, UserMessage

SYSTEM_PROMPT = (
    "You are a reviewer that is intended to evaluate the accuracy of responses. You will be given a question, an expected response, then an 'actual' response that was provided by user. Evaluate the accuracy of the response on a scale of 1 to 3. Here is the key to scoring:\n"
    "- 1 means that the actual response is mostly or wholly inaccurate;\n"
    "- 2 means that the actual response is partly correct, but inaccurate in some respects;\n"
    "- 3 means that the actual response is mostly or entirely accurate.\n"
    "\n"
    "Present your evaluation as follows\n:"
    "\n"
    "Explanation: <insert your explanation here?\n"
    "Score: <1, 2 or 3>\n"
)


def evaluate(model: Callable, question: str, expected: str, actual: str) -> tuple[str, int]:
    system_message = SystemMessage(SYSTEM_PROMPT)

    prompt = f"Question: {question}\nExpected: {expected}\nActual: {actual}\n\nPlease provide an evaluation."
    user_message = UserMessage(prompt)

    response = model([system_message, user_message]).content

    explanation, score = response.split("\nScore: ")

    return explanation, int(score)