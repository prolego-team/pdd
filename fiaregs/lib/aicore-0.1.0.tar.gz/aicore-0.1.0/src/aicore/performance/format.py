import logging

from openpyxl import Workbook
from openpyxl.styles import Font

from aicore.performance.data import Evaluation, evaluation_to_dict


logger = logging.getLogger(__name__)


def to_excel(evaluations: list[Evaluation], filename: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = 'Test Cases'

    columns = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    headers = {
        heading: columns[col_idx]
        for col_idx, heading in enumerate(evaluation_to_dict(evaluations[0]).keys())
    }
    bold_font = Font(bold=True)
    for heading,column in headers.items():
        cell_loc = f'{column}1'
        ws[cell_loc] = heading
        ws[cell_loc].font = bold_font

    for row, evaluation in enumerate(evaluations, start=2):
        for heading, value in evaluation_to_dict(evaluation).items():
            ws[f'{headers[heading]}{row}'] = str(value)

    wb.save(filename)
    logger.info(f'Saved evaluations to {filename}.')

