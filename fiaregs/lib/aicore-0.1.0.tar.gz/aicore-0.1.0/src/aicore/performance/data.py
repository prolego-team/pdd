from dataclasses import dataclass


@dataclass
class Evaluation:
    task: str
    metadata: dict[str, str]
    llm_usage: dict[str, str]
    expected: str
    actual: str
    confidence: str


def evaluation_to_dict(evaluation: Evaluation) -> dict[str, str]:
    output_dict = {
        'Task': evaluation.task
    }
    for k,v in evaluation.metadata.items():
        output_dict[k] = v
    for k,v in evaluation.llm_usage.items():
        output_dict[k] = v
    output_dict.update({
        'Expected': evaluation.expected,
        'Actual': evaluation.actual,
        'Confidence': evaluation.confidence
    })
    return output_dict