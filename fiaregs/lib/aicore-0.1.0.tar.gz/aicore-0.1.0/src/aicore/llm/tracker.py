from dataclasses import dataclass

@dataclass(frozen=True)
class Usage:
    input_tokens: int
    generated_tokens: int
    elapsed_time_sec: float


class UsageTracker:

    def __init__(self, name: str):
        self.name = name
        self.llm_usage = []

        self.pop_call_index = -1

    def __call__(self, *args, **kwargs) -> None:
        self.update(*args, **kwargs)

    def update(
            self,
            input_tokens: int,
            generated_tokens: int,
            elapsed_time: float
        ) -> None:
        self.llm_usage.append(
            Usage(input_tokens, generated_tokens, elapsed_time)
        )

    def pop(self) -> Usage:
        """Pop from FRONT of llm_usage list. Item is NOT removed."""
        self.pop_call_index += 1
        if self.pop_call_index >= len(self.llm_usage):
            raise IndexError('pop from empty UsageTracker')
        return self.llm_usage[self.pop_call_index]

    def get_total_input_tokens(self) -> int:
        """Get the total number of input tokens used."""
        return sum(usage.input_tokens for usage in self.llm_usage)

    def get_total_generated_tokens(self) -> int:
        """Get the total number of tokens generated."""
        return sum(usage.generated_tokens for usage in self.llm_usage)

    def get_total_elapsed_time(self) -> float:
        """Get the total elapsed time."""
        return sum(usage.elapsed_time_sec for usage in self.llm_usage)

    def print_usage(self) -> None:
        """Print the usage."""
        print(f'Usage for {self.name}:')
        print(f'  Total input tokens: {self.get_total_input_tokens()}')
        print(f'  Total generated tokens: {self.get_total_generated_tokens()}')
        print(f'  Total elapsed time: {self.get_total_elapsed_time()} sec')


def get_usage_tracker(name: str) -> UsageTracker:
    """Functional interface for creating usage trackers."""
    return UsageTracker(name)