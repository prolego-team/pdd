import re

import pdfplumber

from prolego.text.text import Page, Document

block_type_to_str = lambda t: 'text' if t==0 else 'image' if t==1 else 'unknown'

# def clip(rect: tuple) -> tuple:
#     return (rect[2]/2, rect[1], rect[2], rect[3])

SKIP_PATTERNS = [
    re.compile(r'Page \d+$'),
    re.compile(r'^Approved \d{1,2}/\d{1,2}/\d{4} / Revised \d{1,2}/\d{1,2}/\d{4}')
]


def pdf_to_doc(filename: str) -> Document:
    """Parse a PDF file into a Document."""
    pages = []
    with pdfplumber.open(filename) as pdf:
        for i,page in enumerate(pdf.pages):
            # print(page.rects)
            text = page.extract_text(layout=True, x_density=7.25, y_density=13)

            # Get rid of extra leading/training white space on each line
            text_parsed = '\n'.join([t.strip() for t in text.split('\n')])
            paragraphs = text_parsed.split('\n\n')
            paragraphs = [
                p for p in text_parsed.split('\n\n')
                if len(p)>0
            ]

            paragraphs = [
                p for p in paragraphs
                if not any([pattern.search(p) for pattern in SKIP_PATTERNS])
            ]

            # for paragraph in paragraphs:
            #     print('---')
            #     print(f'#{paragraph}#')

            pages.append(Page(i, paragraphs))

            # if i>9: exit()

    return pages