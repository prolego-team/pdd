"""Utility functions for search documents."""

from dataclasses import dataclass
from typing import Iterable, Any
from hashlib import md5
import json
from collections import defaultdict

@dataclass
class Page:
    """Store a page of text."""
    page_num: int
    text_blocks: list[str]


Document = Iterable[Page]


@dataclass
class SearchResult:
    """Structure for consistent search results."""
    similarity_score: float
    file: str
    tree_index: tuple
    paragraph_index: int
    chunk_id: int
    text: str
    reranked_score: float = -1000


def clean_text(text: str) -> str:
    """Strip white space and newlines from a string."""
    return text.replace('\n','').strip()


def result_to_string(result: SearchResult) -> str:
    """Format a search result as a string with context."""
    file = result.file
    page = result.tree_index[0]
    paragraph = result.tree_index[1]
    text = result.text

    # uri = DOC_DIR / f'{result.metadata["file"]}'
    # uri = uri.absolute().as_uri() + f'#page={result.metadata["page"]}'

    summary_str = (
        f'From file {file.title()}, page {page}\n\n'
        f'{text}\n'
    )

    return summary_str

