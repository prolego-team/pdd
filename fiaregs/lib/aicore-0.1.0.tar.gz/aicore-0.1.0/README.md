# Prolego Core LLM Library

## Installation

```bash
pip install aicore[dev,search]
```

## Deployment Archive

```bash
pip install --upgrade build
python -m build
```

## Dev

```bash
flake8
```